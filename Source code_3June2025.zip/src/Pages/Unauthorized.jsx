import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import './Unauthorized.css'; // Optional styling file

const Unauthorized = () => {
  const location = useLocation();
  const fromPath = location?.state?.from?.pathname || '/';

  return (
    <div className="unauthorized-container">
      <div className="unauthorized-content">
        <h1>401 - Unauthorized Access</h1>
        <p>You don't have permission to access this page.</p>
        
        <div className="unauthorized-details">
          <p>
            Attempted to access: <code>{fromPath}</code>
          </p>
        </div>

        <div className="unauthorized-actions">
          <Link to="/" className="btn btn-primary">
            Return to Home
          </Link>
          <Link to="/login" className="btn btn-secondary">
            Login with Different Account
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Unauthorized;