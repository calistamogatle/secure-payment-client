import React from 'react';
import { Link } from 'react-router-dom';
import './Home.css'; // Optional styling file

const Home = () => {
  return (
    <div className="home-container">
      <header className="home-header">
        <h1>Welcome to International Payments Portal</h1>
        <p>Secure and efficient international payment processing</p>
      </header>

      <div className="home-actions">
        <div className="action-card">
          <h2>Customer Access</h2>
          <p>Make international payments and view transaction history</p>
          <Link to="/login?role=customer" className="btn btn-primary">
            Customer Login
          </Link>
        </div>

        <div className="action-card">
          <h2>Employee Access</h2>
          <p>Verify and process customer transactions</p>
          <Link to="/login?role=employee" className="btn btn-secondary">
            Employee Login
          </Link>
        </div>
      </div>

      <footer className="home-footer">
        <p>Need help? Contact our support team at ST10100238@rcconnect.edu.za</p>
      </footer>
    </div>
  );
};

export default Home;