import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000';

export const createPayment = async (paymentData) => {
  try {
    const response = await axios.post(`${API_URL}/payments`, paymentData, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    return response.data;
  } catch (error) {
    throw error.response?.data || { message: 'Payment creation failed' };
  }
};

export const getTransactions = async (accountNumber) => {
  try {
    const response = await axios.get(`${API_URL}/transactions`, {
      params: { accountNumber }
    });
    return response.data;
  } catch (error) {
    throw error.response?.data || { message: 'Failed to fetch transactions' };
  }
};

export const getPendingTransactions = async () => {
  const response = await fetch('/api/transactions/pending');
  return await response.json();
};

export const getAccountBalance = async (accountNumber) => {
  try {
    const response = await axios.get(`${API_URL}/accounts/${accountNumber}/balance`);
    return response.data;
  } catch (error) {
    throw error.response?.data || { message: 'Failed to fetch account balance' };
  }
};