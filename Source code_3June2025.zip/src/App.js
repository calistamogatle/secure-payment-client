import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './Contexts/AuthContext';
import RoleBasedRoute from './Components/Auth/RoleBasedRoute';
import CustomerDashboard from './Components/Customer/Dashboard';
import EmployeeDashboard from './Components/Employee/EmployeeDashboard';
import Login from './Components/Auth/Login';
import Home from './Pages/Home';
import Unauthorized from './Pages/Unauthorized';

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          
          {/* Customer Routes */}
          <Route path="/customer" element={
            <RoleBasedRoute allowedRoles={['customer']}>
              <CustomerDashboard />
            </RoleBasedRoute>
          } />
          
          {/* Employee Routes */}
          <Route path="/employee" element={
            <RoleBasedRoute allowedRoles={['employee', 'admin']}>
              <EmployeeDashboard />
            </RoleBasedRoute>
          } />
          
          <Route path="/unauthorized" element={<Unauthorized />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;