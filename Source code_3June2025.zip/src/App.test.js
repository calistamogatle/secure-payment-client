import { render, screen } from '@testing-library/react';
import App from './App';

test('renders Transaction History heading', () => {
  render(<App />);
  const heading = screen.getByText(/transaction history/i);
  expect(heading).toBeInTheDocument();
});
