import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Register = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    idNumber: '',
    accountNumber: '',
    username: '',
    password: '',
    confirmPassword: ''
  });
  const [errors, setErrors] = useState({});
  const [registerSuccess, setRegisterSuccess] = useState(false);
  const navigate = useNavigate();

  // Input validation regex patterns
  const patterns = {
    fullName: /^[a-zA-Z\s]{5,50}$/,
    idNumber: /^[0-9]{13}$/,
    accountNumber: /^[0-9]{9,18}$/,
    username: /^[a-zA-Z0-9_]{5,30}$/,
    password: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/
  };

  const validateInput = (name, value) => {
    if (!value) {
      return `${name} is required`;
    }
    if (!patterns[name]?.test(value)) {
      switch (name) {
        case 'fullName':
          return 'Full name must be 5-50 letters and spaces only';
        case 'idNumber':
          return 'ID number must be exactly 13 digits';
        case 'accountNumber':
          return 'Account number must be 9-18 digits';
        case 'username':
          return 'Username must be 5-30 chars (letters, numbers, underscore)';
        case 'password':
          return 'Password must be 8+ chars with uppercase, lowercase, number and special char';
        default:
          return 'Invalid input';
      }
    }
    if (name === 'confirmPassword' && value !== formData.password) {
      return 'Passwords do not match';
    }
    return '';
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Validate on change
    const error = validateInput(name, value);
    setErrors(prev => ({ ...prev, [name]: error }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validate all fields
    let valid = true;
    const newErrors = {};
    Object.keys(formData).forEach(key => {
      const error = validateInput(key, formData[key]);
      if (error) valid = false;
      newErrors[key] = error;
    });
    setErrors(newErrors);
    
    if (!valid) return;

    try {
      const { confirmPassword, ...dataToSend } = formData;
      const response = await axios.post('/auth/register', dataToSend, {
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]').content
        }
      });
      
      if (response.data.success) {
        setRegisterSuccess(true);
        setTimeout(() => navigate('/login'), 3000);
      }
    } catch (error) {
      console.error('Registration error:', error);
      setErrors(prev => ({ ...prev, form: error.response?.data?.message || 'Registration failed' }));
    }
  };

  if (registerSuccess) {
    return (
      <div className="auth-container">
        <div className="alert alert-success">
          Registration successful! Redirecting to login...
        </div>
      </div>
    );
  }

  return (
    <div className="auth-container">
      <h2>Customer Registration</h2>
      {errors.form && <div className="alert alert-danger">{errors.form}</div>}
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Full Name</label>
          <input
            type="text"
            name="fullName"
            value={formData.fullName}
            onChange={handleChange}
            className={`form-control ${errors.fullName ? 'is-invalid' : ''}`}
          />
          {errors.fullName && <div className="invalid-feedback">{errors.fullName}</div>}
        </div>
        
        <div className="form-group">
          <label>ID Number</label>
          <input
            type="text"
            name="idNumber"
            value={formData.idNumber}
            onChange={handleChange}
            className={`form-control ${errors.idNumber ? 'is-invalid' : ''}`}
          />
          {errors.idNumber && <div className="invalid-feedback">{errors.idNumber}</div>}
        </div>
        
        <div className="form-group">
          <label>Account Number</label>
          <input
            type="text"
            name="accountNumber"
            value={formData.accountNumber}
            onChange={handleChange}
            className={`form-control ${errors.accountNumber ? 'is-invalid' : ''}`}
          />
          {errors.accountNumber && <div className="invalid-feedback">{errors.accountNumber}</div>}
        </div>
        
        <div className="form-group">
          <label>Username</label>
          <input
            type="text"
            name="username"
            value={formData.username}
            onChange={handleChange}
            className={`form-control ${errors.username ? 'is-invalid' : ''}`}
          />
          {errors.username && <div className="invalid-feedback">{errors.username}</div>}
        </div>
        
        <div className="form-group">
          <label>Password</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            className={`form-control ${errors.password ? 'is-invalid' : ''}`}
          />
          {errors.password && <div className="invalid-feedback">{errors.password}</div>}
        </div>
        
        <div className="form-group">
          <label>Confirm Password</label>
          <input
            type="password"
            name="confirmPassword"
            value={formData.confirmPassword}
            onChange={handleChange}
            className={`form-control ${errors.confirmPassword ? 'is-invalid' : ''}`}
          />
          {errors.confirmPassword && <div className="invalid-feedback">{errors.confirmPassword}</div>}
        </div>
        
        <button type="submit" className="btn btn-primary">Register</button>
      </form>
    </div>
  );
};

export default Register;