import React from 'react';
import { useAuth } from '../Hooks/useAuth';
import PendingTransactions from '../Employee/PendingTransactions';

const EmployeeDashboard = () => {
  const auth = useAuth();
  const user = auth?.user ?? null;

  return (
    <div className="employee-dashboard">
      <h1>Employee Portal - International Payments</h1>
      <h2>
        Welcome, {user ? user.name : 'Employee'} (Role: {user ? user.role : 'N/A'})
      </h2>
      
      <PendingTransactions />
    </div>
  );
};

export default EmployeeDashboard;
