import React, { useState, useEffect } from 'react';
import { getPendingTransactions, verifyTransaction } from '../../../Services/PaymentService';
import LoadingSpinner from '../../Common/LoadingSpinner';

const PendingTransactions = () => {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTransactions = async () => {
      const data = await getPendingTransactions();
      setTransactions(data);
      setLoading(false);
    };
    fetchTransactions();
  }, []);

  const handleVerify = async (transactionId) => {
    await verifyTransaction(transactionId);
    setTransactions(prev => prev.filter(t => t.id !== transactionId));
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div>
      <h3>Pending Transactions</h3>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Amount</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {transactions.map(txn => (
            <tr key={txn.id}>
              <td>{txn.id}</td>
              <td>{txn.amount} {txn.currency}</td>
              <td>
                <button onClick={() => handleVerify(txn.id)}>Verify</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default PendingTransactions;