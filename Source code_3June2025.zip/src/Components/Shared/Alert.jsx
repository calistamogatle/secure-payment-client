import React from 'react';

const Alert = ({ type, message, onClose }) => {
  const alertClasses = {
    success: 'alert-success',
    danger: 'alert-danger',
    warning: 'alert-warning',
    info: 'alert-info'
  };

  return (
    <div className={`alert ${alertClasses[type] || 'alert-info'}`} role="alert">
      {message}
      {onClose && (
        <button type="button" className="close" onClick={onClose}>
          <span>&times;</span>
        </button>
      )}
    </div>
  );
};

export default Alert;