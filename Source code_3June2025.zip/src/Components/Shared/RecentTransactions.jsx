import React, { useState, useEffect } from 'react';
import { useAuth } from '../../Hooks/useAuth';
import { getRecentTransactions } from '../../Services/PaymentService';
import { formatCurrency, formatDate } from '../../Utils/helpers';
import LoadingSpinner from './LoadingSpinner';
import './RecentTransactions.css'; // for styling

const RecentTransactions = () => {
  const { user } = useAuth();
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchTransactions = async () => {
      try {
        if (user?.accountNumber) {
          const data = await getRecentTransactions(user.accountNumber);
          setTransactions(Array.isArray(data) ? data.slice(0, 5) : []); // Show only 5 most recent
        }
      } catch (err) {
        setError('Failed to load transactions');
        console.error('Transaction error:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchTransactions();
  }, [user]);

  const getStatusBadge = (status) => {
    const statusClass = {
      completed: 'success',
      pending: 'warning',
      failed: 'danger'
    };

    return (
      <span className={`status-badge ${statusClass[status] || 'info'}`}>
        {status}
      </span>
    );
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <div className="error-message">{error}</div>;

  return (
    <div className="recent-transactions">
      <div className="transactions-header">
        <h3>Recent Transactions</h3>
        <button className="view-all-btn">View All</button>
      </div>

      {transactions.length === 0 ? (
        <div className="no-transactions">No recent transactions found</div>
      ) : (
        <table className="transactions-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Description</th>
              <th>Amount</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map((txn) => (
              <tr key={txn.id}>
                <td>{formatDate(txn.date)}</td>
                <td className="description">
                  {txn.recipientName || 'Unknown recipient'}
                </td>
                <td className={`amount ${txn.type === 'debit' ? 'debit' : 'credit'}`}>
                  {formatCurrency(txn.amount, txn.currency)}
                </td>
                <td>{getStatusBadge(txn.status)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default RecentTransactions;