import React from 'react';
import './LoadingSpinner.scss';

const LoadingSpinner = ({ small = false }) => {
  return (
    <div className={`loading-spinner ${small ? 'small' : ''}`}>
      <div className="spinner-border" role="status">
        <span className="visually-hidden">Loading...</span>
      </div>
    </div>
  );
};

export default LoadingSpinner;