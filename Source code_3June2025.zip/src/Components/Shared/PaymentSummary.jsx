import React from 'react';
import { useAuth } from '../../Hooks/useAuth';
import { formatCurrency } from '../../Utils/helpers';
import './PaymentSummary.css'; // for styling

const PaymentSummary = () => {
  const { user } = useAuth();

  // Sample data - replace with actual API call
  const paymentData = {
    totalSent: 12500.75,
    totalReceived: 8400.50,
    pendingTransactions: 3,
    favoriteCurrency: 'USD'
  };

  return (
    <div className="payment-summary-card">
      <h3 className="summary-title">Payment Summary</h3>
      
      <div className="summary-grid">
        <div className="summary-item">
          <span className="summary-label">Account Balance</span>
          <span className="summary-value">
            {formatCurrency(user?.accountBalance || 0, user?.defaultCurrency || 'USD')}
          </span>
        </div>

        <div className="summary-item">
          <span className="summary-label">Total Sent</span>
          <span className="summary-value">
            {formatCurrency(paymentData.totalSent, paymentData.favoriteCurrency)}
          </span>
        </div>

        <div className="summary-item">
          <span className="summary-label">Total Received</span>
          <span className="summary-value">
            {formatCurrency(paymentData.totalReceived, paymentData.favoriteCurrency)}
          </span>
        </div>

        <div className="summary-item">
          <span className="summary-label">Pending Transactions</span>
          <span className="summary-value">
            {paymentData.pendingTransactions}
          </span>
        </div>
      </div>

      <div className="summary-actions">
        <button className="action-btn primary">
          Make New Payment
        </button>
        <button className="action-btn secondary">
          View All Transactions
        </button>
      </div>
    </div>
  );
};

export default PaymentSummary;