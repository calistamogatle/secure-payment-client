import React from 'react';
import { Link } from 'react-router-dom';
import PaymentSummary from '../Shared/PaymentSummary';
import RecentTransactions from '../Shared/RecentTransactions';

const Dashboard = () => {
  return (
    <div className="dashboard">
      <h1>Welcome to Your International Payments Portal</h1>
      
      <div className="dashboard-grid">
        <div className="dashboard-card">
          <h2>Quick Actions</h2>
          <div className="action-buttons">
            <Link to="/payments/new" className="btn btn-primary">
              Make New Payment
            </Link>
            <Link to="/transactions" className="btn btn-secondary">
              View Transactions
            </Link>
          </div>
        </div>
        
        <PaymentSummary />
        <RecentTransactions />
      </div>
    </div>
  );
};

export default Dashboard;