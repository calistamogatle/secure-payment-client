import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import axios from 'axios';

const Payment = ({ user }) => {
  const [formData, setFormData] = useState({
    amount: '',
    currency: 'USD',
    provider: 'SWIFT',
    recipientAccount: '',
    swiftCode: '',
    recipientName: ''
  });
  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState(false);
  const [balance, setBalance] = useState(0);

  // Input validation regex patterns
  const patterns = {
    amount: /^\d+(\.\d{1,2})?$/,
    recipientAccount: /^[A-Z0-9]{8,34}$/,
    swiftCode: /^[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$/,
    recipientName: /^[a-zA-Z\s]{5,50}$/
  };

  useEffect(() => {
    const fetchBalance = async () => {
      try {
        const response = await axios.get(`/accounts/${user.accountNumber}/balance`);
        setBalance(response.data.balance);
      } catch (error) {
        console.error('Error fetching balance:', error);
      }
    };
    fetchBalance();
  }, [user]);

  const validateInput = (name, value) => {
    if (!value) {
      return `${name} is required`;
    }
    if (!patterns[name].test(value)) {
      switch (name) {
        case 'amount':
          return 'Invalid amount format';
        case 'recipientAccount':
          return 'Invalid account number format';
        case 'swiftCode':
          return 'Invalid SWIFT code format';
        case 'recipientName':
          return 'Recipient name must be 5-50 letters and spaces';
        default:
          return 'Invalid input';
      }
    }
    return '';
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Validate on change
    const error = validateInput(name, value);
    setErrors(prev => ({ ...prev, [name]: error }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validate all fields
    let valid = true;
    const newErrors = {};
    Object.keys(formData).forEach(key => {
      const error = validateInput(key, formData[key]);
      if (error) valid = false;
      newErrors[key] = error;
    });
    setErrors(newErrors);
    
    if (!valid) return;

    try {
      const response = await axios.post('/transactions', {
        ...formData,
        senderAccount: user.accountNumber
      }, {
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]').content
        }
      });
      
      if (response.data.success) {
        setSuccess(true);
        setBalance(prev => prev - parseFloat(formData.amount));
        setFormData({
          amount: '',
          currency: 'USD',
          provider: 'SWIFT',
          recipientAccount: '',
          swiftCode: '',
          recipientName: ''
        });
        setTimeout(() => setSuccess(false), 5000);
      }
    } catch (error) {
      console.error('Payment error:', error);
      setErrors(prev => ({ ...prev, form: error.response?.data?.message || 'Payment failed' }));
    }
  };

  return (
    <div className="payment-container">
      <h2>International Payment</h2>
      <div className="balance-info">
        <h4>Account Balance: {balance.toFixed(2)} {user.defaultCurrency || 'USD'}</h4>
      </div>
      
      {success && <div className="alert alert-success">Payment initiated successfully!</div>}
      {errors.form && <div className="alert alert-danger">{errors.form}</div>}
      
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="amount">Amount</label>
          <input
            id="amount"
            type="text"
            name="amount"
            value={formData.amount}
            onChange={handleChange}
            className={`form-control ${errors.amount ? 'is-invalid' : ''}`}
          />
          {errors.amount && <div className="invalid-feedback">{errors.amount}</div>}
        </div>
        
        <div className="form-group">
          <label htmlFor="currency">Currency</label>
          <select
            id="currency"
            name="currency"
            value={formData.currency}
            onChange={handleChange}
            className="form-control"
          >
            <option value="USD">USD</option>
            <option value="EUR">EUR</option>
            <option value="GBP">GBP</option>
            <option value="ZAR">ZAR</option>
          </select>
        </div>
        
        <div className="form-group">
          <label htmlFor="provider">Provider</label>
          <select
            id="provider"
            name="provider"
            value={formData.provider}
            onChange={handleChange}
            className="form-control"
          >
            <option value="SWIFT">SWIFT</option>
          </select>
        </div>
        
        <div className="form-group">
          <label htmlFor="recipientAccount">Recipient Account Number</label>
          <input
            id="recipientAccount"
            type="text"
            name="recipientAccount"
            value={formData.recipientAccount}
            onChange={handleChange}
            className={`form-control ${errors.recipientAccount ? 'is-invalid' : ''}`}
          />
          {errors.recipientAccount && <div className="invalid-feedback">{errors.recipientAccount}</div>}
        </div>
        
        <div className="form-group">
          <label htmlFor="swiftCode">SWIFT Code</label>
          <input
            id="swiftCode"
            type="text"
            name="swiftCode"
            value={formData.swiftCode}
            onChange={handleChange}
            className={`form-control ${errors.swiftCode ? 'is-invalid' : ''}`}
          />
          {errors.swiftCode && <div className="invalid-feedback">{errors.swiftCode}</div>}
        </div>
        
        <div className="form-group">
          <label htmlFor="recipientName">Recipient Name</label>
          <input
            id="recipientName"
            type="text"
            name="recipientName"
            value={formData.recipientName}
            onChange={handleChange}
            className={`form-control ${errors.recipientName ? 'is-invalid' : ''}`}
          />
          {errors.recipientName && <div className="invalid-feedback">{errors.recipientName}</div>}
        </div>
        
        <button type="submit" className="btn btn-primary">Pay Now</button>
      </form>
    </div>
  );
};
Payment.propTypes = {
  user: PropTypes.shape({
    accountNumber: PropTypes.string.isRequired,
    defaultCurrency: PropTypes.string
  }).isRequired
};

export default Payment;