
import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import axios from 'axios';

const Transaction = ({ user }) => {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchTransactions = async () => {
      try {
        const response = await axios.get(`/transactions?accountNumber=${user.accountNumber}`);
        setTransactions(response.data.transactions);
      } catch (err) {
        console.error('Error fetching transactions:', err);
        setError('Failed to load transactions');
      } finally {
        setLoading(false);
      }
    };
    fetchTransactions();
  }, [user]);

  if (loading) return <div>Loading transactions...</div>;
  if (error) return <div className="alert alert-danger">{error}</div>;

  return (
    <div className="transaction-container">
      <h2>Transaction History</h2>
      <table className="table table-striped">
        <thead>
          <tr>
            <th>Date</th>
            <th>Amount</th>
            <th>Currency</th>
            <th>Recipient</th>
            <th>Recipient Account</th>
            <th>SWIFT Code</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {transactions.length > 0 ? (
            transactions.map((txn) => (
              <tr key={txn.id}>
                <td>{new Date(txn.date).toLocaleString()}</td>
                <td>{txn.amount}</td>
                <td>{txn.currency}</td>
                <td>{txn.recipientName}</td>
                <td>{txn.recipientAccount}</td>
                <td>{txn.swiftCode}</td>
                <td>
                  <span className={`badge ${txn.status === 'completed' ? 'bg-success' : txn.status === 'pending' ? 'bg-warning' : 'bg-danger'}`}>
                    {txn.status}
                  </span>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="7" className="text-center">No transactions found</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};
Transaction.propTypes = {
  user: PropTypes.shape({
    accountNumber: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  }).isRequired,
};

export default Transaction;
