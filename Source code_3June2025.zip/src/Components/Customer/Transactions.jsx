import React, { useState, useEffect } from 'react';
import { useAuth } from '../../Hooks/useAuth';
import { getTransactions } from '../../Services/PaymentService';
import { formatCurrency, formatDate } from '../../Utils/helpers';
import LoadingSpinner from '../Shared/LoadingSpinner';
import Alert from '../Shared/Alert';
import './Transactions.css';

const Transactions = () => {
  const { user } = useAuth();
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filters, setFilters] = useState({
    status: 'all',
    dateRange: '30days',
    searchQuery: ''
  });

  useEffect(() => {
    const fetchTransactions = async () => {
      try {
        if (user?.accountNumber) {
          const data = await getTransactions(user.accountNumber);
          setTransactions(data);
        }
      } catch (err) {
        setError('Failed to load transactions. Please try again later.');
        console.error('Transaction error:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchTransactions();
  }, [user]);

  const filteredTransactions = transactions.filter(txn => {
    // Filter by status
    if (filters.status !== 'all' && txn.status !== filters.status) {
      return false;
    }
    
    // Filter by date range
    const transactionDate = new Date(txn.date);
    const now = new Date();
    let cutoffDate = new Date();
    
    switch (filters.dateRange) {
      case '7days':
        cutoffDate.setDate(now.getDate() - 7);
        break;
      case '30days':
        cutoffDate.setDate(now.getDate() - 30);
        break;
      case '90days':
        cutoffDate.setDate(now.getDate() - 90);
        break;
      case 'all':
      default:
        cutoffDate = new Date(0); // Unix epoch
    }
    
    if (transactionDate < cutoffDate) {
      return false;
    }
    
    // Filter by search query
    if (filters.searchQuery) {
      const query = filters.searchQuery.toLowerCase();
      return (
        txn.id.toLowerCase().includes(query) ||
        (txn.recipientName?.toLowerCase().includes(query)) ||
        txn.currency.toLowerCase().includes(query) ||
        txn.status.toLowerCase().includes(query)
      );
    }
    
    return true;
  });

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  const getStatusBadge = (status) => {
    const statusClasses = {
      completed: 'success',
      pending: 'warning',
      failed: 'danger',
      processing: 'info'
    };
    
    return (
      <span className={`status-badge ${statusClasses[status] || 'secondary'}`}>
        {status}
      </span>
    );
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div className="transactions-container">
      <h2>Transaction History</h2>
      
      {error && <Alert type="danger" message={error} />}

      <div className="transaction-filters">
        <div className="filter-group">
          <label htmlFor="status">Status:</label>
          <select 
            id="status" 
            name="status" 
            value={filters.status}
            onChange={handleFilterChange}
          >
            <option value="all">All Statuses</option>
            <option value="completed">Completed</option>
            <option value="pending">Pending</option>
            <option value="processing">Processing</option>
            <option value="failed">Failed</option>
          </select>
        </div>

        <div className="filter-group">
          <label htmlFor="dateRange">Date Range:</label>
          <select 
            id="dateRange" 
            name="dateRange" 
            value={filters.dateRange}
            onChange={handleFilterChange}
          >
            <option value="7days">Last 7 Days</option>
            <option value="30days">Last 30 Days</option>
            <option value="90days">Last 90 Days</option>
            <option value="all">All Time</option>
          </select>
        </div>

        <div className="filter-group search-group">
          <label htmlFor="search">Search:</label>
          <input
            type="text"
            id="search"
            name="searchQuery"
            placeholder="Search transactions..."
            value={filters.searchQuery}
            onChange={handleFilterChange}
          />
        </div>
      </div>

      {filteredTransactions.length === 0 ? (
        <div className="no-transactions">
          {transactions.length === 0 
            ? 'No transactions found for your account.'
            : 'No transactions match your filters.'}
        </div>
      ) : (
        <div className="transactions-table-container">
          <table className="transactions-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Transaction ID</th>
                <th>Description</th>
                <th>Amount</th>
                <th>Currency</th>
                <th>Status</th>
                <th>Details</th>
              </tr>
            </thead>
            <tbody>
              {filteredTransactions.map(txn => (
                <tr key={txn.id}>
                  <td>{formatDate(txn.date)}</td>
                  <td className="txn-id">{txn.id}</td>
                  <td>
                    {txn.recipientName || 'Unknown Recipient'}
                    {txn.description && <div className="txn-description">{txn.description}</div>}
                  </td>
                  <td className={`amount ${txn.type === 'debit' ? 'debit' : 'credit'}`}>
                    {formatCurrency(txn.amount, txn.currency)}
                  </td>
                  <td>{txn.currency}</td>
                  <td>{getStatusBadge(txn.status)}</td>
                  <td>
                    <button 
                      className="details-btn"
                      onClick={() => console.log('View details', txn.id)}
                    >
                      View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {filteredTransactions.length > 0 && (
        <div className="transaction-summary">
          <div className="summary-item">
            <span>Total Transactions:</span>
            <span>{filteredTransactions.length}</span>
          </div>
          <div className="summary-item">
            <span>Total Amount:</span>
            <span>
              {formatCurrency(
                filteredTransactions.reduce((sum, txn) => sum + txn.amount, 0),
                user?.defaultCurrency || 'USD'
              )}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};

export default Transactions;