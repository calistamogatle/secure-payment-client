
// Currency formatting
export const formatCurrency = (amount, currency = 'USD', locale = 'en-US') => {
  if (isNaN(amount)) return 'Invalid amount';
  
  return new Intl.NumberFormat(locale, {
    style: 'currency',
    currency: currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(amount);
};

// Date formatting
export const formatDate = (dateString, options = {}) => {
  const defaultOptions = { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  };
  
  const mergedOptions = { ...defaultOptions, ...options };
  
  try {
    const date = new Date(dateString);
    if (isNaN(date)) return 'Invalid date';
    return date.toLocaleDateString('en-US', mergedOptions);
  } catch (error) {
    console.error('Date formatting error:', error);
    return 'Invalid date';
  }
};

// SWIFT code validation
export const validateSwiftCode = (swiftCode) => {
  const swiftRegex = /^[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$/;
  return swiftRegex.test(swiftCode);
};

// Account number validation
export const validateAccountNumber = (accountNumber) => {
  const accountRegex = /^[A-Z0-9]{8,34}$/;
  return accountRegex.test(accountNumber);
};

// Amount validation
export const validateAmount = (amount) => {
  const amountRegex = /^[0-9]+(\.[0-9]{1,2})?$/;
  return amountRegex.test(amount) && parseFloat(amount) > 0;
};

// Name validation
export const validateName = (name) => {
  const nameRegex = /^[a-zA-Z\s\-']{2,50}$/;
  return nameRegex.test(name);
};

// Password strength validation
export const validatePassword = (password) => {
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  return passwordRegex.test(password);
};

// Email validation
export const validateEmail = (email) => {
  const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
  return emailRegex.test(email);
};

// Format transaction status
export const formatTransactionStatus = (status) => {
  const statusMap = {
    pending: { class: 'warning', text: 'Pending' },
    completed: { class: 'success', text: 'Completed' },
    failed: { class: 'danger', text: 'Failed' },
    processing: { class: 'info', text: 'Processing' }
  };
  
  return statusMap[status.toLowerCase()] || { class: 'secondary', text: status };
};

// Generate unique ID for transactions
export const generateTransactionId = () => {
  const timestamp = Date.now().toString(36);
  const randomStr = Math.random().toString(36).substring(2, 8);
  return `txn_${timestamp}_${randomStr}`.toUpperCase();
};

// Format large numbers (e.g., 1000 -> 1K)
export const formatLargeNumber = (num, digits = 1) => {
  const lookup = [
    { value: 1, symbol: '' },
    { value: 1e3, symbol: 'K' },
    { value: 1e6, symbol: 'M' },
    { value: 1e9, symbol: 'B' }
  ];
  
  const item = lookup.slice().reverse().find(item => num >= item.value);
  return item ? (num / item.value).toFixed(digits) + item.symbol : '0';
};

// Format phone numbers
export const formatPhoneNumber = (phoneNumber) => {
  if (!phoneNumber) return '';
  const cleaned = phoneNumber.replace(/\D/g, '');
  const match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
  return match ? `(${match[1]}) ${match[2]}-${match[3]}` : phoneNumber;
};

// Debounce function for search inputs
export const debounce = (func, delay = 300) => {
  let timeoutId;
  return function(...args) {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => func.apply(this, args), delay);
  };
};

// Capitalize first letter of each word
export const capitalizeWords = (str) => {
  return str.replace(/\b\w/g, char => char.toUpperCase());
};

// Truncate long strings
export const truncateString = (str, maxLength = 50, suffix = '...') => {
  if (str.length <= maxLength) return str;
  return str.substring(0, maxLength) + suffix;
};

// Get currency symbol
export const getCurrencySymbol = (currencyCode) => {
  return (0)
    .toLocaleString('en-US', {
      style: 'currency',
      currency: currencyCode,
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    })
    .replace(/\d/g, '')
    .trim();
};

// Calculate exchange rate
export const calculateExchange = (amount, rate, decimalPlaces = 2) => {
  const result = amount * rate;
  return parseFloat(result.toFixed(decimalPlaces));
};

// Format bytes to human readable size
export const formatFileSize = (bytes, decimals = 2) => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
};

// Get user initials
export const getUserInitials = (name) => {
  if (!name) return '';
  const names = name.split(' ');
  let initials = names[0].substring(0, 1).toUpperCase();
  if (names.length > 1) {
    initials += names[names.length - 1].substring(0, 1).toUpperCase();
  }
  return initials;
};

// Check if value is empty
export const isEmpty = (value) => {
  if (value === null || value === undefined) return true;
  if (typeof value === 'string' && value.trim() === '') return true;
  if (Array.isArray(value) && value.length === 0) return true;
  if (typeof value === 'object' && Object.keys(value).length === 0) return true;
  return false;
};

// Deep clone object
export const deepClone = (obj) => {
  return JSON.parse(JSON.stringify(obj));
};

// Generate random color
export const getRandomColor = () => {
  const letters = '0123456789ABCDEF';
  let color = '#';
  for (let i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
};

// Export all functions
const helpers = {
  formatCurrency,
  formatDate,
  validateSwiftCode,
  validateAccountNumber,
  validateAmount,
  validateName,
  validatePassword,
  validateEmail,
  formatTransactionStatus,
  generateTransactionId,
  formatLargeNumber,
  formatPhoneNumber,
  debounce,
  capitalizeWords,
  truncateString,
  getCurrencySymbol,
  calculateExchange,
  formatFileSize,
  getUserInitials,
  isEmpty,
  deepClone,
  getRandomColor
};

export default helpers;