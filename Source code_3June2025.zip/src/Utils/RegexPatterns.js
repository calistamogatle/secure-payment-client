export const nameRegex = /^[a-zA-Z ]{2,30}$/;
export const emailRegex = /^[\\w-.]+@([\\w-]+\\.)+[\\w-]{2,4}$/;
export const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])(?=.{8,})/;
export const accountNumberRegex = /^[A-Z0-9]{6,20}$/;
