export const validateEmail = (email) => {
  const re = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
  return re.test(String(email).toLowerCase());
};

export const validatePassword = (password) => {
  // Minimum 8 chars, at least 1 uppercase, 1 lowercase, 1 number and 1 special char
  const re = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  return re.test(password);
};

export const validateAccountNumber = (accountNumber) => {
  const re = /^\d{9,18}$/;
  return re.test(accountNumber);
};

export const validateSwiftCode = (swiftCode) => {
  const re = /^[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$/;
  return re.test(swiftCode);
};

export const validateAmount = (amount) => {
  const re = /^\d+(\.\d{1,2})?$/;
  return re.test(amount);
};

export const validateName = (name) => {
  const re = /^[a-zA-Z\s]{5,50}$/;
  return re.test(name);
};