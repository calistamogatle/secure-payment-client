import { createContext, useState, useEffect, useMemo, useCallback } from 'react';
import PropTypes from 'prop-types';
import {loginUser,logoutUser,verifyAuth } from '../Services/AuthService';


export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const userData = await verifyAuth();
        setUser(userData);
      } catch (error) {
        console.error('Authentication verification failed:', error);
        setUser(null);
      } finally {
        setLoading(false);
      }
    };
    checkAuth();
  }, []);

const login = useCallback(async (credentials) => {
  const userData = await loginUser(credentials); 
  setUser(userData);
  return userData;
}, []);

const logout = useCallback(async () => {
  await logoutUser(); 
  setUser(null);
}, []);


  const contextValue = useMemo(
    () => ({ user, loading, login, logout }),
    [user, loading, login, logout]
  );

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
};
AuthProvider.propTypes = {
  children: PropTypes.node.isRequired,
};